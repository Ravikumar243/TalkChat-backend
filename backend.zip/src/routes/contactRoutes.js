const express = require("express");
const User = require("../models/User");
const  verifyAccessToken  = require("../middleware/authmiddleware");

const router = express.Router();


router.get("/contacts", verifyAccessToken, async (req, res) => {
  try {

    const currentUserId = req.user.id;

    
    const users = await User.find({ _id: { $ne: currentUserId } });

    const formatted = users.map((u) => ({
      id: u._id,
      name: u.name,
      phone: u.phoneNumber,
    }));

    res.status(200).json({ success: true, data: formatted });
  } catch (error) {
    console.error("Error fetching contacts:", error);
    res.status(500).json({ success: false, message: "Failed to fetch contacts" });
  }
});

module.exports = router;
